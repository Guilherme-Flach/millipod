#ifndef PLAYERCONTROL_H
#define PLAYERCONTROL_H

#include "definitions.h"

// Reads input from keyboard and mouse and stores the relevant information
void getInputFromPlayer(PLAYERINPUT *playerInput);

#endif